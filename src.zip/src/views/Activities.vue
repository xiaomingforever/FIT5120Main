<template>
  <h1 class="act-title">Exercises Collection</h1>
  <section class="card">This is the Activities page content.</section>
</template>

<style scoped>
.act-title {
  text-align: center;
  font-size: clamp(28px, 3vw, 48px);
  line-height: 1.05;
  margin: 0 0 8px;
}

.card {
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 16px;
  padding: 22px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
  width: min(960px, 88vw);
  margin: 0 auto;
}
</style>
